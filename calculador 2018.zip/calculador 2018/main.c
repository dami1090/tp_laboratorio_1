#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    char input[31];
    char seguir='s';
    int opcion=0;
    float num1=0;
    float num2=0;
    int aux;

    while(seguir=='s')
    {
        printf("1- Ingresar 1er operando (A=%.2f)\n",num1);
        printf("2- Ingresar 2do operando (B=%.2f)\n",num2);
        printf("3- Calcular la suma (A+B)\n");
        printf("4- Calcular la resta (A-B)\n");
        printf("5- Calcular la division (A/B)\n");
        printf("6- Calcular la multiplicacion (A*B)\n");
        printf("7- Calcular el factorial (A!)\n");
        printf("8- Calcular todas las operaciones\n");
        printf("9- Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            //  printf("ingrese un numero para A:");
            //scanf("%f",&num1);
            aux= getStringNumeros("ingrese un numero para A:", input);
            if(aux==1)
            {
                num1=atof(input);
            }
            else
                printf("deben ingresarse solo numeros, punto'.' o menos'-'\n");
            break;
        case 2:
            aux= getStringNumeros("\ningrese un numero para B:", input);
            if(aux==1)
            {
                num2=atof(input);
            }
            else
                printf("\ndeben ingresarse solo numeros, punto'.' o menos'-'\n");
            break;
        case 3:
            suma(num1,num2);
            break;
        case 4:
            resta(num1,num2);
            break;
        case 5:
            dividir(num1,num2);
            break;
        case 6:
            multi(num1,num2);
            break;
        case 7:
            factorial(num1);
            break;
        case 8:
            suma(num1,num2);
            resta(num1,num2);
            dividir(num1,num2);
            multi(num1,num2);
            factorial(num1);
            break;
        case 9:
            seguir = 'n';
            break;

        default:
            system("cls");
            setbuf(stdin,NULL);
            printf("\n\tOpcion invalida\n\n");
            break;
        }
        opcion=0;
        system("pause");
        system("cls");
    }
    return 0;
}
