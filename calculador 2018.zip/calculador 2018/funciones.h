#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
/** \brief suma 2 numeros y los muestra por pantalla
 *
 * \param numero A a ser sumado
 * \param numero B a ser sumado
 * \return devuelve el resultado
 *
 */

float suma(float , float);
/** \brief resta 2 numeros y los muestra por pantalla
 *
 * \param numero A a ser restado
 * \param numero B a ser restado
 * \return devuelve el resultado
 *
 */
float resta(float , float );
/** \brief divide2 numeros y los muestra por pantalla
 *
 * \param numero A dividendo
 * \param numero B a divisor
 * \return devuelve el resultado
 *
 */
float dividir(float , float );
/** \brief multiplica 2 numeros y los muestra por pantalla
 *
 * \param numero A a ser multiplicado
 * \param numero B multiplicador
 * \return devuelve el resultado
 *
 */
float multi(float , float);
/** \brief realiza factorial de A y lo muestra por pantalla
 *
 * \param numero A
 * \return devuelve el resultado
 *
 */
float factorial(float);
/**
 * \brief Verifica si el valor recibido es num�rico
 * \param str Array con la cadena a ser analizada
 * \return 1 si es n�merico y 0 si no lo es
 *
 */
int esNumerico(char str[]);
/**
 * \brief Solicita un texto al usuario y lo devuelve
 * \param mensaje Es el mensaje a ser mostrado
 * \param input Array donde se cargar� el texto ingresado
 * \return void
 */
void getString(char mensaje[],char input[]);
/**
 * \brief Solicita un texto num�rico al usuario y lo devuelve
 * \param mensaje Es el mensaje a ser mostrado
 * \param input Array donde se cargar� el texto ingresado
 * \return 1 si el texto contiene solo n�meros y/o '.' y/o '-'.
 */
int getStringNumeros(char mensaje[],char input[]);

#endif // FUNCIONES_H_INCLUDED
