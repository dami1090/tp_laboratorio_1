#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

float suma(float a, float b)
{
    float res;
    res=a+b;
    printf("La suma es: %.2f\n",res);
    return res;
}
float resta(float a, float b)
{
    float res;

    res=a-b;
    printf("La resta es: %.2f\n",res);

    return res;
}
float dividir(float a, float b)
{
    float res;
    if(b>=1)
    {
        res=a/b;
        printf("La division es: %.2f\n",res);
        return res;
    }
    else
    {
        printf("El divisor debe ser siempre mayor a 0\n");
        return -1;
    }

}
float multi(float a, float b)
{
    float res;
    res=a*b;
    printf("la multiplicacion es: %.2f\n",res);
    return res;
}
float factorial(float a)
{

    float i;
    if(a>=0)
    {

        float res=1;
        for(i=1; i<=a; i++)
        {
            res=res*(i);
        }

        printf("el factorial de A! es: %.2f\n",res);
        return res;
    }
    else
    {
        float res=-1;
        for(i=-1; i>=a; i--)
        {
            res=res*(i);
        }
        printf("el factorial de A! es: %.2f\n",res);
        return res;
    }

}
int esNumerico(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] < '0' || str[i] > '9') && (str[i]!= '.') && (str[i]!= '-'))
           return 0;
       i++;
   }
   return 1;
}

void getString(char mensaje[],char input[])
{
    printf("%s",mensaje);
    scanf ("%s", input);
}

int getStringNumeros(char mensaje[],char input[])
{
    char aux[256];
    getString(mensaje,aux);
    if(esNumerico(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

