#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#include "utn.h"
#define TAM 10

int main()
{
    int auxCargar;

    char seguir='s';
    int opcion=0;
    EMovie movie[TAM];
    inicializarEstado( movie, TAM);
    while(seguir=='s')
    {
        printf("1- Agregar pelicula\n");
        printf("2- Modificar o borrar pelicula\n");
        printf("3- Guardar y generar pagina web\n");
        printf("4- Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                auxCargar=agregarPelicula(movie,TAM);
                if(auxCargar==1)
                {
                    printf("\tla pelicula se agrego correctamente\n");
                    system("pause");
                    system("cls");
                }
                else if(auxCargar==0)
                {
                    printf("\n\tno hay lugar para cargar mas peliculas\n\n");
                    system("pause");
                    system("cls");
                }
                else if(auxCargar==-1)
                {
                    printf("\n\tla pelicula no se cargo a pedido del usuario\n\n");
                    system("pause");
                    system("cls");
                }
                break;
            case 2:
                auxCargar= borrarPelicula(movie,TAM);
                if(auxCargar==3)
                {
                    printf("no encontro esa pelicula\n");
                    system("pause");
                    system("cls");
                }
                else if(auxCargar==2)
                {
                    printf("La pelicula se borro correctamente \n");
                    system("pause");
                    system("cls");
                }
                else if(auxCargar==1)
                {
                    printf("La pelicula se modifico correctamente \n");
                    system("pause");
                    system("cls");
                }
                else if(auxCargar==-1)
                {
                    printf("La pelicula no se modifico  \n");
                    system("pause");
                    system("cls");
                }

                break;
            case 3:
               auxCargar= guardarArchivo(movie,"datos.dat",TAM);
                if (auxCargar != 1)
            {
                generarPagina(movie,"index.html",TAM);
                printf("Las peliculas fueron generadas y guardadas \n");
                system("pause");
                system("cls");
            }
            else
            {
                printf("Peliculas no guardadas \n");
                system("pause");
                system("cls");
            }
               break;
            case 4:
                seguir = 'n';
                break;

            default:
                system("cls");
            printf("\n\tOpcion invalida\n\n");

            break;
        }
    }

    return 0;
}
