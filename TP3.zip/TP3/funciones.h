#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#define TAM 10
typedef struct{
    char titulo[50];
    char genero[50];
    int duracion;
    char descripcion[1000];
    int puntaje;
    char linkImagen[300];
    int estado;
}EMovie;

/** \brief
 *inicializa todos los espacios libre
 * \param movie la estructura
 * \param el taman�o de la estruc
 * \return
 *
 */

void inicializarEstado(EMovie* movie, int t);
/** \brief
 * buscar espacio libre en la estrucura para ocuparlo
 * \param movie la estructura
 * \param el taman�o de la estruc
 * \return si encontro lugar validando con 1 o 0
 *
 */

int obtenerEspacioLibre(EMovie* movie , int t) ;

/**
 *  Agrega una pelicula al archivo binario
 *  @param movie la estructura a ser agregada al archivo
 *  @return retorna 1 o 0 de acuerdo a si pudo agregar la pelicula o no
 */
int agregarPelicula(EMovie* movie, int t);

/**
 *  Borra una pelicula del archivo binario
 *  @param movie la estructura a ser eliminada al archivo
 *  @return retorna 1 o 0 de acuerdo a si pudo eliminar la pelicula o no
 */
int borrarPelicula(EMovie* movie,int t);

/**
 *  Genera un archivo html a partir de las peliculas cargadas en el archivo binario.
 *  @param lista la lista de peliculas a ser agregadas en el archivo.
 *  @param nombre el nombre para el archivo.
 */
void generarPagina(EMovie* movie, char html[],int t);
/** \brief
 * buscar peliculas por el titulo
 * \param la estrucuraa
 * \param el tama�o
 * \param el aux a comparar eltitulo con el titulo ya guardado
 * \return -1 sino encontro similitud, pero en caso contrario, retornara la posicion en la q se encuentra el titulo de la pelicula buscada
 *
 */

int buscarPelicula(EMovie* movie, int t,char aux[]);
/** \brief
 *muestra una lista de las peliculas cargadas
 * \param movie es la estructura
 * \param el tama�o
 * \return void
 *
 */

void listarPeliculas(EMovie* movie,int t);
/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int contadorFuncion(EMovie* movie, int t);

/** \brief
 * genera, reescribe el arch
 * \param movie la estructura
 * \param nombre del file a guardar
 * \param el tama�o
 * \return si guardo o no el file 1 o 0
 *
 */
int guardarArchivo(EMovie* movie, char ubicacion[] ,int t);
#endif // FUNCIONES_H_INCLUDED
