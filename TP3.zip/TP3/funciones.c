#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>
#include "funciones.h"
#include "utn.h"

void inicializarEstado(EMovie* movie, int t)
{
    int i;
    for(i=0; i<t; i++)
    {
        (movie+i)->estado = 0;
    }
}
int obtenerEspacioLibre(EMovie* movie, int t)
{
    int i;
    for(i = 0; i < t; i++)
    {
        if((movie+i)->estado == 0)
        {
            return i;
        }
    }

    return -1;
}


int agregarPelicula(EMovie* movie, int t)
{
    int i;
    int lugar;
    char resp;
    lugar = obtenerEspacioLibre(movie, t);
    if (lugar==-1)
    {
        printf("\n\tsin espacio para seguir almacenando peliculas\n");
        return;
    }

    for(i=0; i<t; i++)
    {
        if((movie+i)->estado==0)
        {
            printf("Ingrese el titulo de la pelicula: \n");
            fflush(stdin);
            gets((movie+i)->titulo);
            printf("Ingrese el genero de la pelicula: \n");
            fflush(stdin);
            gets((movie+i)->genero);
            printf("Ingrese la duracion de la pelicula (minutos): \n");
            scanf("%d",&(movie+i)->duracion);
            printf("ingrese la descripcion de la pelicula: \n");
            fflush(stdin);
            gets((movie+i)->descripcion);
            printf("ingrese el puntaje de la pelicula(0 a 100)(unicamente numeros): \n");
            scanf("%d",&(movie+i)->puntaje);
            printf("ingrese el link de la imagen de la pelicula: \n");
            fflush(stdin);
            gets((movie+i)->linkImagen);

            /*  getString("Ingrese el titulo de la pelicula: \n",(movie+i)->titulo);
              getString("Ingrese el genero de la pelicula: \n",(movie+i)->genero);
              (movie+i)->duracion=getInt("Ingrese la duracion de la pelicula (minutos): \n");
              getString("ingrese la descripcion de la pelicula: \n",(movie+i)->descripcion);
              (movie+i)->puntaje=getFloat("ingrese el puntaje de la pelicula: \n");

              getString("ingrese el link de la imagen de la pelicula: \n",(movie+i)->linkImagen);*/

            printf("el titulo es: %s \n",&(movie+i)->titulo);
            printf("el genero es: %s \n",&(movie+i)->genero);
            printf("la duracion es: %d \n",(movie+i)->duracion);
            printf("la descripcion  es: %s \n",&(movie+i)->descripcion);
            printf("el puntaje es: %d \n",(movie+i)->puntaje);
            printf("el link de la imagen es: %s \n",&(movie+i)->linkImagen);
            resp = getChar(" estos datos son correctos? s/n\n");
            if(resp == 's')
            {
                (movie+i)->estado = 1;
                return 1;

            }
            else if (resp == 'n')
            {
                return -1;
            }

        }
    }
    return 0;
}

int borrarPelicula(EMovie* movie,int t)
{
    int i;
    int auxEliminar;
    int resp;
    int auxResp;
    int peliculaModificada;
    char auxTitulo[50];
    char auxiliarT[50];
    char auxiliarG[50];
    int auxiliarD;
    char auxiliarDES[1000];
    int auxiliarP;
    char auxiliarLINK[300];
    int posicion;

    listarPeliculas( movie, t);
    printf("ingrese el TITULO de la pelicula a modificar: \n");
    fflush(stdin);
    gets(auxTitulo);
    posicion = buscarPelicula(movie,t,auxTitulo);

    if (posicion != -1)
    {
        printf("el titulo es: %s \n",&(movie+posicion)->titulo);
        printf("el genero es: %s \n",&(movie+posicion)->genero);
        printf("la duracion es: %d \n",(movie+posicion)->duracion);
        printf("la descripcion  es: %s \n",&(movie+posicion)->descripcion);
        printf("el puntaje es: %d \n",(movie+posicion)->puntaje);
        printf("el link de la imagen es: %s \n",&(movie+posicion)->linkImagen);
        resp=getChar("es pelciula que desea ?(s/n)\n");
        if(resp=='s')
        {
            printf("Desea (1)modificar o (2)borrar esta pelicula? \n");
            scanf("%d",&auxResp);
            if(auxResp==1)
            {
                printf("Ingrese el titulo de la pelicula: \n");
                fflush(stdin);
                gets(auxiliarT);
                printf("Ingrese el genero de la pelicula: \n");
                fflush(stdin);
                gets(auxiliarG);
                printf("Ingrese la duracion de la pelicula (minutos): \n");
                scanf("%d",&auxiliarD);
                printf("ingrese la descripcion de la pelicula: \n");
                fflush(stdin);
                gets(auxiliarDES);
                printf("ingrese el puntaje de la pelicula(0 a 100)(unicamente numeros): \n");
                scanf("%d",&auxiliarP);
                printf("ingrese el link de la imagen de la pelicula: \n");
                fflush(stdin);
                gets(auxiliarLINK);

                printf("el titulo es: %s \n",&auxiliarT);
                printf("el genero es: %s \n",&auxiliarG);
                printf("la duracion es: %d \n",auxiliarD);
                printf("la descripcion  es: %s \n",&auxiliarDES);
                printf("el puntaje es: %d \n",auxiliarP);
                printf("el link de la imagen es: %s \n",&auxiliarLINK);
                resp = getChar(" estos datos son correctos? s/n\n");

                if(resp == 's')
                {
                    strcpy((movie+posicion)->titulo,auxiliarT);
                    strcpy((movie+posicion)->genero,auxiliarG);
                    strcpy((movie+posicion)->descripcion,auxiliarDES);
                    strcpy((movie+posicion)->linkImagen,auxiliarLINK);
                    (movie+posicion)->duracion==auxiliarD;
                    (movie+posicion)->puntaje==auxiliarP;

                    return 1;
                }
                else if (resp == 'n')
                    return -1;

            }
            else if(auxResp==2)
            {
                (movie+posicion)->estado=0;
                return 2;
            }


        }

    }
    return 3;
}

int buscarPelicula(EMovie* movie, int t,char aux[])
{
    int i;
    int index;
    for(i=0; i<t; i++)
    {
        if ((movie+i)->estado != 0 && stricmp((movie+i)->titulo,aux)==0)
        {
            index = i;
            break;
        }
        else
        {
            index = -1;
        }

    }
    return index;
}

void listarPeliculas(EMovie* movie,int t)
{
    int i;

    for(i=0; i<t; i++)
    {
        if((movie+i)->estado !=0 )
        {
            printf("\t%d %s\n",i+1,(movie+i)->titulo);
        }
    }
}
int guardarArchivo(EMovie* movie,char ubicacion[],int t)
{
    int aux =0;
    int contador;
    int i;
    FILE* f;
    f=fopen(ubicacion, "wb");
    if(f != NULL)
    {
        contador = contadorFuncion(movie,t);
        fwrite(&contador, sizeof(int), 1, f);
        for(i=0; i<t; i++)
        {
            if((movie+i)->estado!=0)
            {
                fwrite(movie+i, sizeof(EMovie), 1, f);
            }
        }
        fclose(f);
    }
    else
    {
        aux = 1;
    }
    return aux;
}

void generarPagina(EMovie* movie, char htmlAUX[],int t)
{
    FILE* html;
    int i;
    html = fopen(htmlAUX,"w");
    if (html!=NULL)
    {
        fprintf(html, "<html lang='en'><head><meta charset='utf-8'><meta http-equiv='X-UA-Compatible' content='IE=edge'><meta name='viewport' content='width=device-width, initial-scale=1'><!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags --><title>Lista de peliculas</title><!-- Bootstrap Core CSS --><link href='css/bootstrap.min.css' rel='stylesheet'><!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles --><link href='css/custom.css' rel='stylesheet'><!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries --><!-- WARNING: Respond.js doesn't work if you view the page via file:// --><!--[if lt IE 9]><script src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js'></script><script src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js'></script><![endif]--></head><body><div class='container'><div class='row'>");
        for(i=0; i<t; i++)
        {
            if((movie+i)->estado != 0)
            {
                fprintf(html,"<article class='col-md-4 article-intro'>");
                fprintf(html,"<a href='#'>");
                fprintf(html,"<img class='img-responsive img-rounded' src='%s' alt=''>",(movie+i)->linkImagen);
                fprintf(html,"</a>");
                fprintf(html,"<h3>");
                fprintf(html,"<a href='#'> %s </a>",(movie+i)->titulo);
                fprintf(html,"</h3>");
                fprintf(html,"<ul>");
                fprintf(html,"<li>Genero:%s</li>",(movie+i)->genero);
                fprintf(html,"<li>Puntaje:%d</li>",(movie+i)->puntaje);
                fprintf(html,"<li>Duracion:%d</li>",(movie+i)->duracion);
                fprintf(html,"</ul>");
                fprintf(html,"<p>%s</p>",(movie+i)->descripcion);
                fprintf(html,"</article>");
            }
        }
        fprintf(html, "</div><!-- /.row --></div><!-- /.container --><!-- jQuery --><script src='js/jquery-1.11.3.min.js'></script>\<!-- Bootstrap Core JavaScript --><script src='js/bootstrap.min.js'></script><!-- IE10 viewport bug workaround --><script src='js/ie10-viewport-bug-workaround.js'></script><!-- Placeholder Images --><script src='js/holder.min.js'></script></body></html>");
    }
    else
    {
        printf("No existe archivo ");
    }
    fclose(html);

    return 0;
}



int contadorFuncion(EMovie* movie, int t)
{
    int contador=0;
    int i;
    for(i=0; i<t; i++)
    {
        if((movie+i)->estado != 0)
        {
            contador++;
        }
    }
    return contador;
}

